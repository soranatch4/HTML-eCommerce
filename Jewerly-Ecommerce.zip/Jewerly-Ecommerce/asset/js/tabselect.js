var allBtn = document.querySelector('#all');
var Btn2021 = document.querySelector('#Earring');
var Btn2020 = document.querySelector('#Bracelet');
var Btn2019 = document.querySelector('#Ring');
var Btn2018 = document.querySelector('#Necklace');
var allContent = document.querySelectorAll('.col.mb-5');


// Displays all the images.
allBtn.addEventListener('click', ()=>{
    allContent.forEach(item =>{
        item.style.display = 'flex';
    });
});
// Displays all the car images.
Btn2021.addEventListener('click', ()=>{
    allContent.forEach(item =>{
        console.log(item)
           if(item.title !== 'Earring'){
               item.style.display = 'none';
           }else{
             item.style.display = 'flex';
           }
    });
});


Btn2020.addEventListener('click', ()=>{
    allContent.forEach(item =>{
           if(item.title !== 'Bracelet'){
               item.style.display = 'none';
           }else{
             item.style.display = 'flex';
           }
    });
});


Btn2019.addEventListener('click', ()=>{
    allContent.forEach(item =>{
           if(item.title !== 'Ring'){
               item.style.display = 'none';
           }else{
             item.style.display = 'flex';
           }
    });
});

Btn2018.addEventListener('click', ()=>{
    allContent.forEach(item =>{
           if(item.title !== 'Necklace'){
               item.style.display = 'none';
           }else{
             item.style.display = 'flex';
           }
    });
});