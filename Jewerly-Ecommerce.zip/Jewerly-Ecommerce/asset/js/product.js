function OpenCart(){
	document.location = "/th/jewelry/cart.html";
}

function CheckOut(){
	document.location = "/th/jewelry/check-out.html";
}

function Purchase(){
	document.location = "/th/jewelry/thankyou.html";
}